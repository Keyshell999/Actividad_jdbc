
package com.mycompany.jdbctest;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Jdbctest {

    public static void main(String[] args) {
        
        String usuario = "root";
        String password = "";
        String url = "jdbc:mysql://localhost:3306/mydb";
        Connection conexion;
        Statement statement;
        ResultSet rs;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Jdbctest.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            conexion = DriverManager.getConnection(url, usuario, password);
            statement = conexion.createStatement();
            
            //Consulta de datos
            rs = statement.executeQuery("SELECT * FROM cliente");
            rs.next();
            
            do{
                System.out.println(rs.getInt("id_cliente") + " : " + rs.getString("nombre_CL") + " : " + rs.getInt("edad_CL"));
            }
            while(rs.next());
            
            
            //Insercion de datos
            statement.executeUpdate("INSERT INTO `cliente` (`id_cliente`, `nombre_CL`, `edad_CL`) VALUES (NULL, 'Esteban', '31');");
            System.out.println("");
            rs = statement.executeQuery("SELECT * FROM cliente");
            rs.next();
            
            do{
                System.out.println(rs.getInt("id_cliente") + " : " + rs.getString("nombre_CL") + " : " + rs.getInt("edad_CL"));
            }
            while(rs.next());
            
            
            //Actualizacion de datos
           statement.executeUpdate("UPDATE `cliente` SET `nombre_CL` = 'Miguel' WHERE `cliente`.`nombre_CL` = 'Keyshell';");
            System.out.println("");
            rs = statement.executeQuery("SELECT * FROM cliente");
            rs.next();
            
            do{
                System.out.println(rs.getInt("nombre_CL"));
            }
            while(rs.next());
            
            
            //Eliminar o borrar
            statement.execute("DELETE FROM cliente WHERE `cliente`.`id_cliente` = 3");
            System.out.println("");
            rs = statement.executeQuery("SELECT * FROM cliente");
            rs.next();
            
            do{
                System.out.println(rs.getString("nombre_CL"));
            }
            while(rs.next());
        
            
        } catch (SQLException ex) {
            Logger.getLogger(Jdbctest.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}